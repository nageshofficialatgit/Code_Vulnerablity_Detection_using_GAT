import numpy as np

# Path to the transfer feature embedding file
embedding_file = r'C:\Users\asus\Desktop\seems\solidity_embeddings.npy'

# Load the transfer feature embedding
embedding = np.load(embedding_file, allow_pickle=True)

# Display the shape and the content of the embedding
print("Shape of the embedding:", embedding.shape)
print("Embedding content:\n", embedding)
