import os
import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, SAGEConv, global_mean_pool
from torch_geometric.data import Data, DataLoader
import networkx as nx
import numpy as np

class GNN(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GNN, self).__init__()
        # Define GNN layers
        self.conv1 = SAGEConv(input_dim, hidden_dim)
        self.conv2 = SAGEConv(hidden_dim, hidden_dim)
        # MLP for readout
        self.fc1 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, output_dim)

    def forward(self, x, edge_index, batch):
        # Apply GNN layers with ReLU activation
        x = F.relu(self.conv1(x, edge_index))
        x = F.relu(self.conv2(x, edge_index))

        # Readout: Aggregate node embeddings for each graph
        x = global_mean_pool(x, batch)

        # Apply fully connected layers to get final graph embedding
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Set the path to the cache folder
cache_path = "/path/to/cache"

# Parameters
input_dim = 128  # Node feature dimension (adjust based on your embeddings)
hidden_dim = 64  # Hidden dimension for GNN layers
output_dim = 32  # Final output dimension (e.g., for classification)
learning_rate = 0.001
num_epochs = 50
batch_size = 4

# Prepare dataset
data_list = []
for folder_name in os.listdir(cache_path):
    folder_path = os.path.join(cache_path, folder_name)
    if os.path.isdir(folder_path):
        # Load the graph
        graph_file = os.path.join(folder_path, "Graph.gml")
        graph = nx.read_gml(graph_file)
        edge_index = torch.tensor(list(graph.edges), dtype=torch.long).t().contiguous()

        # Load node features
        node_features = []
        for node in graph.nodes:
            embedding_file = os.path.join(folder_path, f"{node}_embedding.npy")
            if os.path.exists(embedding_file):
                node_features.append(np.load(embedding_file))
            else:
                node_features.append(np.zeros(input_dim))
        
        x = torch.tensor(node_features, dtype=torch.float)
        data = Data(x=x, edge_index=edge_index)
        data_list.append(data)

# Use a DataLoader to load the graphs in batches
loader = DataLoader(data_list, batch_size=batch_size, shuffle=True)

# Initialize the GNN model
model = GNN(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim)
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

# Training loop
model.train()
for epoch in range(num_epochs):
    total_loss = 0
    for data in loader:
        optimizer.zero_grad()
        # Pass batch data through the GNN model
        data = data.to('cpu')  # If running on GPU, switch to 'cuda'
        out = model(data.x, data.edge_index, data.batch)
        
        # Dummy target for demonstration (use actual labels if available)
        target = torch.randint(0, 2, (data.num_graphs,), dtype=torch.long)  # Example binary labels
        loss = F.cross_entropy(out, target)
        
        # Backpropagation
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    
    print(f"Epoch {epoch+1}/{num_epochs}, Loss: {total_loss / len(loader)}")

print("Training completed.")
