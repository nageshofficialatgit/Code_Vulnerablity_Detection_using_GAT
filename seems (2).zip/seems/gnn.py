import os
import networkx as nx
import numpy as np
import torch
import torch.nn.functional as F

# Set the path to the cache folder
cache_path = r'C:\Users\asus\Desktop\seems\cache'


# Initialize network parameters
node_feature_dim = 128  # Adjust this to match the dimension of function embeddings
edge_feature_dim = node_feature_dim  # Assuming edge features are same size as node features

W_k = torch.randn((node_feature_dim * 2, node_feature_dim), requires_grad=True)
b_k = torch.randn((node_feature_dim,), requires_grad=True)
U = torch.randn((node_feature_dim, node_feature_dim), requires_grad=True)
Z = torch.randn((node_feature_dim, node_feature_dim), requires_grad=True)
R = torch.randn((node_feature_dim, node_feature_dim), requires_grad=True)
b_3 = torch.randn((node_feature_dim,), requires_grad=True)
b_4 = torch.randn((node_feature_dim,), requires_grad=True)

# Define the message-passing function
def propagate(graph, node_features, W_k, b_k, U, Z, R, b_3, b_4):
    updated_node_features = node_features.clone()

    for edge in graph.edges:
        start_node, end_node = edge
        # Concatenate start node feature with edge feature (if available, else zero vector)
        x_k = torch.cat((node_features[start_node], torch.zeros(edge_feature_dim)), dim=0)
        m_k = W_k @ x_k + b_k

        # Update end node's hidden state
        h_end = torch.tanh(U @ m_k + Z @ updated_node_features[end_node] + b_3)
        updated_node_features[end_node] = F.softmax(R @ h_end + b_4, dim=0)

    return updated_node_features

# Process each subfolder in the cache
for folder_name in os.listdir(cache_path):
    folder_path = os.path.join(cache_path, folder_name)
    if os.path.isdir(folder_path):
        # Load the graph
        graph_file = os.path.join(folder_path, "function_graph.gml")
        graph = nx.read_gml(graph_file)

        # Initialize a dictionary to hold the function embeddings by node ID
        function_embeddings = {}

        # Load each function embedding file
        for file_name in os.listdir(folder_path):
            if file_name.endswith("_embedding.npy"):
                function_name = file_name.replace("_embedding.npy", "")
                embedding_file = os.path.join(folder_path, file_name)
                function_embeddings[function_name] = np.load(embedding_file)

        # Map each node in the graph to its embedding
        node_features_list = []
        for node in graph.nodes:
            # Ensure each node has an associated embedding
            if node in function_embeddings:
                node_features_list.append(function_embeddings[node])
            else:
                # If there's no embedding for the node, initialize a zero vector
                node_features_list.append(np.zeros(node_feature_dim))

        # Convert node features to a PyTorch tensor
        node_features = torch.tensor(node_features_list, dtype=torch.float)

        # Perform propagation for each function graph
        num_steps = 3  # Number of propagation steps
        for _ in range(num_steps):
            node_features = propagate(graph, node_features, W_k, b_k, U, Z, R, b_3, b_4)

        # Aggregate features for the graph (entire smart contract)
        E_c = torch.sum(node_features, dim=0)

        # Save the final embedding for the smart contract
        output_path = os.path.join(folder_path, "contract_embedding.npy")
        np.save(output_path, E_c.detach().numpy())

        print(f"Processed {folder_name} and saved embedding to {output_path}")
